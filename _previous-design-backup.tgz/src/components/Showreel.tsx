"use client";

import { useReducedMotion } from "motion/react";
import { useEffect, useRef } from "react";

export function Showreel() {
  const ref = useRef<HTMLVideoElement>(null);
  const reduce = useReducedMotion();

  useEffect(() => {
    const video = ref.current;
    if (!video) return;
    if (reduce) {
      video.pause();
      return;
    }
    // Stop decoding while the hero is scrolled away.
    const io = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) video.play().catch(() => {});
      else video.pause();
    });
    io.observe(video);
    return () => io.disconnect();
  }, [reduce]);

  return (
    <video
      ref={ref}
      className="aspect-video w-full object-cover"
      src="/media/showreel.mp4"
      poster="/media/showreel-poster.jpg"
      width={1440}
      height={810}
      autoPlay={!reduce}
      muted
      loop
      playsInline
      preload="metadata"
      aria-label="Showreel of Dovli, CrestClip, Rent Rush, Klaude, VizPilot and Sahayak"
    />
  );
}
