import { EnvelopeSimple, GithubLogo, LinkedinLogo, XLogo } from "@phosphor-icons/react/ssr";
import { profile } from "@/content/site";
import { CopyEmail } from "./CopyEmail";
import { Reveal } from "./Reveal";

const socials = [
  { label: "GitHub", href: profile.github, Icon: GithubLogo },
  { label: "LinkedIn", href: profile.linkedin, Icon: LinkedinLogo },
  { label: "X", href: profile.x, Icon: XLogo },
];

export function Contact() {
  return (
    <footer id="contact" className="border-t border-line">
      <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
        <Reveal>
          <h2 className="max-w-[16ch] text-5xl font-semibold leading-[1.02] tracking-[-0.045em] sm:text-7xl">
            Building something? I&apos;d like to hear about it.
          </h2>
          <p className="mt-6 max-w-[50ch] text-lg text-muted">
            Open to collaborating on full-stack, AI-powered and product-led projects.
          </p>
          <div className="mt-10 flex flex-wrap items-center gap-3">
            <a
              href={`mailto:${profile.email}`}
              className="inline-flex h-12 items-center gap-2 rounded-full bg-accent px-6 text-[15px] font-semibold text-accent-ink transition hover:opacity-90 active:scale-[0.98]"
            >
              <EnvelopeSimple size={17} weight="bold" />
              Email me
            </a>
            <CopyEmail email={profile.email} />
          </div>
          <p className="mt-4 font-mono text-sm text-muted select-all">{profile.email}</p>
        </Reveal>

        <div className="mt-20 flex flex-col-reverse items-start justify-between gap-6 border-t border-line pt-8 sm:flex-row sm:items-center">
          <p className="text-sm text-muted">
            © 2026 Mayank Jha. Hero reel rendered with HyperFrames.
          </p>
          <ul className="flex items-center gap-1">
            {socials.map(({ label, href, Icon }) => (
              <li key={label}>
                <a
                  href={href}
                  target="_blank"
                  rel="noreferrer"
                  aria-label={label}
                  className="grid size-10 place-items-center rounded-full text-muted transition hover:bg-surface-2 hover:text-ink"
                >
                  <Icon size={19} weight="bold" />
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </footer>
  );
}
