import { ArrowUpRight, GitMerge } from "@phosphor-icons/react/ssr";
import { contributions, mergedTotal, profile } from "@/content/site";
import { Reveal } from "./Reveal";

export function OpenSource() {
  return (
    <section id="open-source" className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
      <Reveal>
        <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:gap-10">
          <p className="text-[6.5rem] font-semibold leading-[0.85] tracking-[-0.06em] text-accent sm:text-[9rem]">
            {mergedTotal}
          </p>
          <div className="pb-2">
            <h2 className="text-3xl font-semibold tracking-[-0.035em] sm:text-4xl">merged pull requests</h2>
            <p className="mt-2 max-w-[52ch] text-lg text-muted">
              Fixes, features and test suites in open-source projects I didn&apos;t start.
            </p>
          </div>
        </div>
      </Reveal>

      <div className="mt-14 grid grid-cols-1 gap-px overflow-hidden rounded-[20px] border border-line bg-line md:grid-cols-2">
        {contributions.map((c, i) => (
          <Reveal key={c.project} delay={(i % 2) * 0.08} className="h-full">
            <a
              href={c.href}
              target="_blank"
              rel="noreferrer"
              className="group flex h-full flex-col bg-surface p-7 transition hover:bg-surface-2 sm:p-9"
            >
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="text-sm text-muted">{c.org}</p>
                  <h3 className="mt-1 text-xl font-semibold tracking-[-0.02em]">{c.project}</h3>
                </div>
                <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full bg-surface-2 px-3 py-1.5 font-mono text-[13px] group-hover:bg-bg">
                  <GitMerge size={14} weight="bold" />
                  {c.merged} merged
                </span>
              </div>
              <p className="mt-2 text-sm text-muted">{c.blurb}</p>
              <p className="mt-5 leading-relaxed">{c.did}</p>
              <span className="mt-auto inline-flex items-center gap-1 pt-6 text-sm font-medium text-muted group-hover:text-ink">
                View pull requests <ArrowUpRight size={14} weight="bold" />
              </span>
            </a>
          </Reveal>
        ))}
      </div>

      <p className="mt-6 text-sm text-muted">
        Plus one merged PR to LiquidGalaxyLAB. Older work lives on my first account,{" "}
        <a href={profile.githubOld} target="_blank" rel="noreferrer" className="underline underline-offset-4 hover:text-ink">
          @MayankJha014
        </a>
        .
      </p>
    </section>
  );
}
