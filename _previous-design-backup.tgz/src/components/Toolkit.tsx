import { toolkit } from "@/content/site";

function Row({ hidden }: { hidden?: boolean }) {
  return (
    <ul className="flex shrink-0 items-center gap-12 pr-12" aria-hidden={hidden || undefined}>
      {toolkit.map((t) => (
        <li key={t.slug} className="flex items-center gap-3 text-muted">
          {/* A mask lets one CDN logo take the current theme's colour. */}
          <span
            className="block size-6 bg-current"
            style={{
              maskImage: `url(https://cdn.simpleicons.org/${t.slug})`,
              WebkitMaskImage: `url(https://cdn.simpleicons.org/${t.slug})`,
              maskSize: "contain",
              WebkitMaskSize: "contain",
              maskRepeat: "no-repeat",
              WebkitMaskRepeat: "no-repeat",
              maskPosition: "center",
              WebkitMaskPosition: "center",
            }}
          />
          <span className="whitespace-nowrap text-[15px] font-medium">{t.name}</span>
        </li>
      ))}
    </ul>
  );
}

export function Toolkit() {
  return (
    <section aria-label="Toolkit" className="border-y border-line py-8">
      <div className="marquee overflow-hidden [mask-image:linear-gradient(90deg,transparent,#000_8%,#000_92%,transparent)]">
        <div className="marquee-track flex w-max">
          <Row />
          <Row hidden />
        </div>
      </div>
    </section>
  );
}
