import { ArrowDown, EnvelopeSimple } from "@phosphor-icons/react/ssr";
import { profile } from "@/content/site";
import { Showreel } from "./Showreel";

export function Hero() {
  return (
    <section id="top" className="mx-auto grid max-w-7xl items-center gap-10 px-4 pb-16 pt-12 sm:px-6 md:pt-16 lg:grid-cols-12 lg:gap-12 lg:px-8 lg:pb-24 lg:pt-20">
      <div className="hero-in lg:col-span-5">
        <p className="text-sm font-medium text-muted">
          {profile.name}, {profile.role.toLowerCase()}
        </p>
        <h1 className="mt-5 text-[2.6rem] font-semibold leading-[1.02] tracking-[-0.04em] sm:text-6xl lg:text-[4.1rem]">
          I take products from idea to <span className="text-accent">launch.</span>
        </h1>
        <p className="mt-6 max-w-[46ch] text-lg leading-relaxed text-muted">
          Web apps, mobile apps and VS Code extensions, often with AI inside. Currently a full-stack intern at
          Pulsegen.
        </p>
        <div className="mt-9 flex flex-wrap items-center gap-3">
          <a
            href="#work"
            className="inline-flex h-12 items-center gap-2 rounded-full bg-ink px-6 text-[15px] font-medium text-bg transition hover:opacity-90 active:scale-[0.98]"
          >
            See my work
            <ArrowDown size={16} weight="bold" />
          </a>
          <a
            href={`mailto:${profile.email}`}
            className="inline-flex h-12 items-center gap-2 rounded-full border border-line px-6 text-[15px] font-medium transition hover:bg-surface-2 active:scale-[0.98]"
          >
            <EnvelopeSimple size={16} weight="bold" />
            Email me
          </a>
        </div>
      </div>

      <div className="hero-in [animation-delay:120ms] lg:col-span-7">
        <div className="overflow-hidden rounded-[20px] border border-line bg-[#0e0f10] shadow-[var(--shadow)]">
          <Showreel />
        </div>
      </div>
    </section>
  );
}
