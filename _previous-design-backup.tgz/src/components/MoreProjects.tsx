import { ArrowUpRight, GithubLogo } from "@phosphor-icons/react/ssr";
import { moreProjects, profile } from "@/content/site";
import { Reveal } from "./Reveal";

export function MoreProjects() {
  return (
    <section aria-labelledby="more-title" className="pb-16 lg:pb-24">
      <Reveal className="mx-auto flex max-w-7xl flex-wrap items-end justify-between gap-4 px-4 sm:px-6 lg:px-8">
        <h2 id="more-title" className="text-3xl font-semibold tracking-[-0.035em] sm:text-4xl">
          More things I&apos;ve built
        </h2>
        <a
          href={`${profile.github}?tab=repositories`}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-1 text-sm font-medium text-muted hover:text-ink"
        >
          All repositories <ArrowUpRight size={14} weight="bold" />
        </a>
      </Reveal>

      <ul
        className="mt-10 flex snap-x snap-mandatory gap-4 overflow-x-auto px-4 pb-4 [scrollbar-width:thin] sm:px-6 scroll-px-4 sm:scroll-px-6 lg:px-[max(2rem,calc((100vw_-_80rem)/2_+_2rem))] lg:scroll-px-[max(2rem,calc((100vw_-_80rem)/2_+_2rem))]"
        aria-label="More projects"
      >
        {moreProjects.map((p) => (
          <li
            key={p.name}
            className="flex w-[82vw] max-w-[340px] shrink-0 snap-start flex-col rounded-[20px] border border-line bg-surface p-6 sm:w-[340px]"
          >
            <h3 className="text-lg font-semibold tracking-[-0.02em]">{p.name}</h3>
            <p className="mt-2 leading-relaxed text-muted">{p.summary}</p>
            <p className="mt-4 font-mono text-[12.5px] text-muted">{p.stack}</p>
            <div className="mt-auto flex gap-4 pt-6 text-sm font-medium">
              <a href={p.code} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 hover:text-accent">
                <GithubLogo size={15} weight="bold" /> Code
              </a>
              {p.live && (
                <a href={p.live} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 hover:text-accent">
                  Live <ArrowUpRight size={14} weight="bold" />
                </a>
              )}
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}
