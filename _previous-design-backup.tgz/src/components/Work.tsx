import { ArrowUpRight, GithubLogo } from "@phosphor-icons/react/ssr";
import Image from "next/image";
import { featured, type Project } from "@/content/site";
import { Reveal } from "./Reveal";

// Bento spans per card, in the order of `featured`. Dovli leads as a wide horizontal card.
const layout: Record<string, { cell: string; horizontal?: boolean; reverse?: boolean }> = {
  dovli: { cell: "lg:col-span-12", horizontal: true },
  crestclip: { cell: "lg:col-span-7" },
  rentrush: { cell: "lg:col-span-5" },
  klaude: { cell: "lg:col-span-5" },
  vizpilot: { cell: "lg:col-span-7" },
  sahayak: { cell: "lg:col-span-12", horizontal: true, reverse: true },
};

function Links({ p }: { p: Project }) {
  return (
    <div className="mt-6 flex flex-wrap gap-2">
      {p.live && (
        <a
          href={p.live}
          target="_blank"
          rel="noreferrer"
          className="inline-flex h-10 items-center gap-1.5 rounded-full bg-ink px-4 text-sm font-medium text-bg transition hover:opacity-90 active:scale-[0.98]"
        >
          {p.slug === "klaude" ? "Install" : "Live"}
          <ArrowUpRight size={14} weight="bold" />
        </a>
      )}
      {p.code && (
        <a
          href={p.code}
          target="_blank"
          rel="noreferrer"
          className="inline-flex h-10 items-center gap-1.5 rounded-full border border-line px-4 text-sm font-medium transition hover:bg-surface-2 active:scale-[0.98]"
        >
          <GithubLogo size={15} weight="bold" />
          Code
        </a>
      )}
      {p.extra && (
        <a
          href={p.extra.href}
          target="_blank"
          rel="noreferrer"
          className="inline-flex h-10 items-center gap-1.5 rounded-full border border-line px-4 text-sm font-medium transition hover:bg-surface-2 active:scale-[0.98]"
        >
          {p.extra.label}
          <ArrowUpRight size={14} weight="bold" />
        </a>
      )}
    </div>
  );
}

function Card({ p, index }: { p: Project; index: number }) {
  const { cell, horizontal, reverse } = layout[p.slug];
  const href = p.live ?? p.code;
  return (
    <Reveal delay={(index % 2) * 0.08} className={`col-span-1 ${cell}`}>
      <article
        className={`group flex h-full flex-col overflow-hidden rounded-[20px] border border-line bg-surface p-3 shadow-[var(--shadow)] ${
          horizontal ? "lg:grid lg:grid-cols-12 lg:items-center lg:gap-8" : ""
        }`}
      >
        <a
          href={href}
          target="_blank"
          rel="noreferrer"
          tabIndex={-1}
          aria-hidden
          className={`relative block aspect-video overflow-hidden rounded-[14px] bg-surface-2 ${horizontal ? "lg:col-span-7" : ""} ${reverse ? "lg:order-2" : ""}`}
        >
          <Image
            src={p.image}
            alt={p.imageAlt}
            fill
            sizes={horizontal ? "(min-width: 1024px) 700px, 100vw" : "(min-width: 1024px) 50vw, 100vw"}
            className="object-cover object-top transition duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-[1.025]"
          />
        </a>
        <div className={`flex flex-1 flex-col px-3 pb-4 pt-6 ${horizontal ? `lg:col-span-5 lg:py-6 ${reverse ? "lg:pl-8" : "lg:pr-8"}` : ""}`}>
          <h3 className="text-2xl font-semibold tracking-[-0.03em] sm:text-[1.75rem]">{p.name}</h3>
          <p className="mt-3 max-w-[58ch] leading-relaxed text-muted">{p.summary}</p>
          <p className="mt-5 font-mono text-[13px] leading-relaxed text-muted">{p.stack.join("  /  ")}</p>
          <div className="mt-auto">
            <Links p={p} />
          </div>
        </div>
      </article>
    </Reveal>
  );
}

export function Work() {
  return (
    <section id="work" className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
      <Reveal>
        <h2 className="text-4xl font-semibold tracking-[-0.04em] sm:text-5xl">Selected work</h2>
        <p className="mt-4 max-w-[60ch] text-lg leading-relaxed text-muted">
          Products I designed, built and shipped, from the database to the store listing.
        </p>
      </Reveal>
      <div className="mt-12 grid grid-cols-1 gap-5 lg:grid-cols-12">
        {featured.map((p, i) => (
          <Card key={p.slug} p={p} index={i} />
        ))}
      </div>
    </section>
  );
}
