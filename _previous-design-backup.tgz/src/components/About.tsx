import { FileText } from "@phosphor-icons/react/ssr";
import Image from "next/image";
import { education, experience, profile } from "@/content/site";
import { Reveal } from "./Reveal";

export function About() {
  return (
    <section id="about" className="border-t border-line bg-surface">
      <div className="mx-auto grid max-w-7xl gap-12 px-4 py-16 sm:px-6 lg:grid-cols-12 lg:gap-16 lg:px-8 lg:py-24">
        <Reveal className="lg:col-span-5">
          <Image
            src="/work/avatar.png"
            alt="Mayank Jha"
            width={460}
            height={460}
            className="size-24 rounded-full border border-line object-cover"
          />
          <h2 className="mt-8 text-4xl font-semibold tracking-[-0.04em] sm:text-5xl">About</h2>
          <div className="mt-6 max-w-[52ch] space-y-4 text-lg leading-relaxed text-muted">
            <p>
              I&apos;m a full-stack developer who likes owning a product end to end: the design, the code, the release
              and whatever breaks after it.
            </p>
            <p>
              Most days that means React, Next.js and Node, with Expo or Flutter for mobile. Lately I&apos;m going deeper on
              RAG pipelines and system design at scale.
            </p>
          </div>
          <a
            href={profile.resume}
            target="_blank"
            rel="noreferrer"
            className="mt-8 inline-flex h-11 items-center gap-2 rounded-full border border-line px-5 text-sm font-medium transition hover:bg-surface-2 active:scale-[0.98]"
          >
            <FileText size={16} weight="bold" />
            Resume
          </a>
        </Reveal>

        <Reveal delay={0.1} className="lg:col-span-7">
          <h3 className="text-sm font-medium text-muted">Experience</h3>
          <ol className="mt-6 space-y-8 border-l border-line pl-8">
            {experience.map((r, i) => (
              <li key={r.company} className="relative">
                <span
                  aria-hidden
                  className={`absolute -left-[37px] top-1.5 size-2.5 rounded-full ring-4 ring-surface ${i === 0 ? "bg-accent" : "bg-muted/50"}`}
                />
                <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
                  <p className="text-lg font-semibold tracking-[-0.02em]">
                    {r.company}
                    {r.title && <span className="font-normal text-muted">, {r.title}</span>}
                  </p>
                  <p className="font-mono text-[13px] text-muted">{r.period}</p>
                </div>
                <p className="mt-2 max-w-[60ch] leading-relaxed text-muted">{r.detail}</p>
              </li>
            ))}
          </ol>

          <h3 className="mt-14 text-sm font-medium text-muted">Education</h3>
          <div className="mt-4 flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
            <p className="text-lg font-semibold tracking-[-0.02em]">
              {education.degree}
              <span className="block font-normal text-muted sm:inline">, {education.school}</span>
            </p>
            <p className="font-mono text-[13px] text-muted">{education.period}</p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
