import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Mayank Jha, full-stack developer",
  description:
    "I take products from idea to launch: web apps, mobile apps, VS Code extensions and AI tools. Dovli, CrestClip, Rent Rush, Klaude and more.",
  openGraph: {
    title: "Mayank Jha, full-stack developer",
    description: "Products I designed, built and shipped, plus 30 merged open-source pull requests.",
    images: ["/media/showreel-poster.jpg"],
  },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#f4f4f2" },
    { media: "(prefers-color-scheme: dark)", color: "#0e0f10" },
  ],
};

// Runs before paint so a saved theme never flashes the system one first.
const themeScript = `(function(){try{var t=localStorage.getItem("theme");if(t==="light"||t==="dark")document.documentElement.setAttribute("data-theme",t)}catch(e){}})()`;

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html
      lang="en"
      suppressHydrationWarning
      className={`${geistSans.variable} ${geistMono.variable} antialiased`}
    >
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body className="min-h-[100dvh]">{children}</body>
    </html>
  );
}
